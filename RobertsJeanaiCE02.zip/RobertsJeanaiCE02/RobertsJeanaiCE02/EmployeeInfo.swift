//
//  PastEmployers.swift
//  RobertsJeanaiCE02
//
// Jeanai Roberts
// CE01
// 08/02/2021
// C202108
//

import Foundation

class EmployeeInfo{
    
    let companyName: String!
    let responsibilities: [String]!
    
    
    
    init(companyName: String!, responsibilities: [String]!) {
        self.companyName = companyName
        self.responsibilities = responsibilities
    }
    
    
    
    
}

