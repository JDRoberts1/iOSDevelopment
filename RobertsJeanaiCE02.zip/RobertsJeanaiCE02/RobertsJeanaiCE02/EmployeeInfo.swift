//
//  PastEmployers.swift
//  RobertsJeanaiCE02
//
//  Created by Nai Roberts on 7/3/21.
//

import Foundation

class EmployeeInfo{
    
    let companyName: String!
    let responsibilities: [String]!
    
    
    
    init(companyName: String!, responsibilities: [String]!) {
        self.companyName = companyName
        self.responsibilities = responsibilities
    }
    
    
    
    
}

