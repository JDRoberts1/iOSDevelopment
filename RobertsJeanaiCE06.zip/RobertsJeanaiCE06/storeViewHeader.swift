//
//  storeViewHeader.swift
//  RobertsJeanaiCE06
//
//  Created by Nai Roberts on 8/15/21.
//

import UIKit

class storeViewHeader: UITableViewHeaderFooterView {

    
    @IBOutlet weak var storeCountLabel: UILabel!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
