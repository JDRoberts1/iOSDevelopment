//
//  needToPurchase.swift
//  RobertsJeanaiCE06
//
//  Created by Nai Roberts on 8/19/21.
//

import UIKit

class needToPurchase: UITableViewHeaderFooterView {

    @IBOutlet weak var SectionLabel: UILabel!
    @IBOutlet weak var CountLabel: UILabel!
    
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
